package com.example.demo.jpa.controller;

import com.example.demo.jpa.domain.dto.DemoListDto;
import com.example.demo.jpa.domain.dto.DemoSaveDto;
import com.example.demo.jpa.domain.dto.DemoUpdateDto;
import com.example.demo.jpa.service.DemoService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * DemoController.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */

/**
 * @HTTP 메서드 호출 표준
 * GET : 데이터 조회
 * POST : 데이터 저장
 * PUT : 데이터 수정
 * DELETE : 데이터 삭제
 */

/**
 * @프로세스
 * Controller -> Service -> (ServiceImpl) -> Repository -> DB
 */
@Controller
@RequiredArgsConstructor
@RequestMapping("/demo") // 해당 컨트롤러를 호출할 URL
public class DemoController {
    private final DemoService demoService;


    /**
     * http://localhost:8080/demo를 GET 메서드로 호출 시 실행됨
     * Thymeleaf 사용 시 return 되는 경로의 html 파일을 찾아 렌더링
     * -> resources/templates/demo/demoList.html
     * Model 객체를 통해 데이터 전달하며, 해당 데이터는 html에서 변수로 불러와 사용 가능
     */
    @GetMapping
    public String list(Model model) {
        List<DemoListDto> demoList = demoService.selectDemoData();
        model.addAttribute("demoList", demoList);
        return "demo/demoList";
    }

    /**
     * http://localhost:8080/demo를 POST 메서드로 호출 시 실행됨
     * 저장할 데이터는 Body 값으로 전달
     */
    @PostMapping
    public ResponseEntity saveDemoData(@RequestBody DemoSaveDto demoSaveDto) {
        demoService.saveDemoData(demoSaveDto);
        return new ResponseEntity(HttpStatus.OK);
    }

    /**
     * http://localhost:8080/demo를 PUT 메서드로 호출 시 실행됨
     * 업데이트 할 Data는 Body 값으로 전달
     */
    @PutMapping
    public ResponseEntity updateDemoData(@RequestBody DemoUpdateDto demoUpdateDto) {
        demoService.updateDemoData(demoUpdateDto);
        return new ResponseEntity(HttpStatus.OK);
    }

    /**
     * http://localhost:8080/demo/{id}를 DELETE 메서드로 호출 시 실행됨
     * PathVariable로 URL에 있는 id 값을 받아와 삭제
     */
    @PostMapping("/{id}")
    public ResponseEntity deleteDemoData(@PathVariable Long id) {
        demoService.deleteDemoData(id);
        return new ResponseEntity(HttpStatus.OK);
    }
}
