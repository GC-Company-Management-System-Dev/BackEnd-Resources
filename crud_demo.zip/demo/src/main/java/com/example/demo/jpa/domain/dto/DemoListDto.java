package com.example.demo.jpa.domain.dto;

import com.example.demo.jpa.domain.entity.DemoEntity;
import lombok.Getter;

/**
 * DemoListDto.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */
@Getter
public class DemoListDto {
    private String demoData;

    public static DemoListDto of(DemoEntity entity) {
        return new DemoListDto(entity);
    }

    public DemoListDto(DemoEntity entity) {
        this.demoData = entity.getDemoData();
    }
}
