package com.example.demo.jpa.domain.dto;

import com.example.demo.jpa.domain.entity.DemoEntity;
import lombok.Getter;

/**
 * DemoSaveDto.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */
@Getter
public class DemoUpdateDto {
    private Long id;
    private String demoData;

    public DemoEntity toEntity(DemoUpdateDto demoSaveDto) {
        return DemoEntity.builder()
                .demoData(demoSaveDto.getDemoData())
                .build();
    }
}
