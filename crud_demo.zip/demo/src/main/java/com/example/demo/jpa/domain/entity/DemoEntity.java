package com.example.demo.jpa.domain.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * DemoSaveEntity.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */
@Getter
@Entity
@NoArgsConstructor
@Table(name = "tb_demo")
public class DemoEntity {
    @Id
    @Column(name = "demo_code")
    private String demoCode;

    @Column(name = "demo_data")
    private String demoData;


    @Builder
    public DemoEntity(String demoCode, String demoData) {
        this.demoCode = demoCode;
        this.demoData = demoData;
    }

    public void update(String demoData) {
        this.demoData = demoData;
    }
}
