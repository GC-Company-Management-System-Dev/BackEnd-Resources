package com.example.demo.jpa.repository;

import com.example.demo.jpa.domain.entity.DemoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * DemoRepository.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */

/**
 *
 * JpaRepository를 상속받아 CRUD를 사용할 수 있음
 * save, findById, findAll, delete 등의 메서드는 기본으로 제공 됨
 *
 */
public interface DemoRepository extends JpaRepository<DemoEntity, Long> {

}
