package com.example.demo.jpa.service;

import com.example.demo.jpa.domain.dto.DemoListDto;
import com.example.demo.jpa.domain.dto.DemoSaveDto;
import com.example.demo.jpa.domain.dto.DemoUpdateDto;
import java.util.List;

/**
 * DemoService.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */
public interface DemoService {
    List<DemoListDto> selectDemoData();
    void saveDemoData(DemoSaveDto demoSaveDto);
    void updateDemoData(DemoUpdateDto demoUpdateDto);
    void deleteDemoData(Long id);
}
