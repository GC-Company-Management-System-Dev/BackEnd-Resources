package com.example.demo.jpa.service.impl;

import com.example.demo.jpa.domain.dto.DemoListDto;
import com.example.demo.jpa.domain.dto.DemoSaveDto;
import com.example.demo.jpa.domain.dto.DemoUpdateDto;
import com.example.demo.jpa.domain.entity.DemoEntity;
import com.example.demo.jpa.repository.DemoRepository;
import com.example.demo.jpa.service.DemoService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * DemoServiceImpl.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */


/**
 *
 * 의존성 분리를 위해 Service 단에서 메서드 추상화 후 Impl에서 구현하는 방식으로 구현 하였으나,
 * Service / Impl을 분리하지 않고 DemoService에서 직접 로직 구현해도 무방함
 *
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DemoServiceImpl implements DemoService {
    private final DemoRepository demoRepository;


    @Override
    public List<DemoListDto> selectDemoData() {
        return demoRepository.findAll().stream().map(DemoListDto::of).toList();
    }

    /**
     * DemoSaveDto를 받아 DemoEntity로 변환 후 저장
     * -> Repository 전달 시에는 Entity 객체를 전달해야 함
     *
     */
    @Override
    public void saveDemoData(DemoSaveDto demoSaveDto) {
        demoRepository.save(demoSaveDto.toEntity(demoSaveDto));
    }


    @Override
    public void updateDemoData(DemoUpdateDto demoUpdateDto) {
        // 데이터 Update 시에는 우선 기존 데이터를 불러와야 함
        DemoEntity demoEntity = demoRepository.findById(demoUpdateDto.getId()).orElseThrow(() -> new IllegalArgumentException("해당 데이터가 없습니다."));
        // 불러온 entity에서 변경할 값을 update
        demoEntity.update(demoUpdateDto.getDemoData());
        // 다시 저장 시 update 처리 됨
        demoRepository.save(demoEntity);
    }

    @Override
    public void deleteDemoData(Long id) {
        // 해당 테이블의 고유 ID 값을 통해 delete 처리
        demoRepository.deleteById(id);
    }
}
