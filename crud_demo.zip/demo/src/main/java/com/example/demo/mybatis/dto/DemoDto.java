package com.example.demo.mybatis.dto;

import com.example.demo.mybatis.entity.DemoListEntity;
import com.example.demo.mybatis.entity.DemoSaveEntity;
import com.example.demo.mybatis.entity.DemoUpdateEntity;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

/**
 * DemoDto.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */

/**
 * resources의 Mapper 하위의 xml 파일과 연결
 * DemoMapper.xml의 ID 값을 찾아 쿼리를 실행함
 */
@Mapper
public interface DemoDto {
    List<DemoListEntity> getDemoList();
    void saveDemoData(DemoSaveEntity saveEntity);
    void updateDemoData(DemoUpdateEntity updateEntity);
    void deleteDemoData(Long id);
}
