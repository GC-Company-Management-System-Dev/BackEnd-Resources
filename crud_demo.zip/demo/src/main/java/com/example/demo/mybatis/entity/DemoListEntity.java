package com.example.demo.mybatis.entity;

import lombok.Getter;

/**
 * DemoListEntity.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */
@Getter
public class DemoListEntity {
    private String demoData;
}
