package com.example.demo.mybatis.service;

import com.example.demo.mybatis.dto.DemoDto;
import com.example.demo.mybatis.entity.DemoListEntity;
import com.example.demo.mybatis.entity.DemoSaveEntity;
import com.example.demo.mybatis.entity.DemoUpdateEntity;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * DemoServiceImpl.java
 *
 * @Author dory
 * @createdAt 2024/05/14
 */

@Slf4j
@Service
@RequiredArgsConstructor
public class DemoService {
    private final DemoDto demoDto;
    
    public List<DemoListEntity> selectDemoData() {
        return demoDto.getDemoList();
    }

    /**
     * DemoSaveDto를 받아 DemoEntity로 변환 후 저장
     * -> Repository 전달 시에는 Entity 객체를 전달해야 함
     *
     */
    public void saveDemoData(DemoSaveEntity saveEntity) {
        demoDto.saveDemoData(saveEntity);
    }


    
    public void updateDemoData(DemoUpdateEntity updateEntity) {
        demoDto.updateDemoData(updateEntity);
    }

    
    public void deleteDemoData(Long id) {
        demoDto.deleteDemoData(id);
    }
}
