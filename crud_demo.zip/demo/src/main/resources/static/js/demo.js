window.onload = () => {
  document.querySelector('#btnSave').addEventListener('click', saveData);
}

function saveData() {
  const data = {'demoData':'test'}

  // localhost:8080/demo를 POST로 호출함
  fetch(`/demo`, {
    method: 'POST',
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(data)
  })
  .then(response => {
      alert("저장 되었습니다.");
  })
}